#include <iostream>
#include <string>
#include <map>
using namespace std;

int main() {
	char c;
	string nom;
	map<string,int> m;
	while(cin >> c >> nom) {
		if(c == 'a') ++m[nom];
		else cout << m[nom] << endl;
	}
}
		
			
